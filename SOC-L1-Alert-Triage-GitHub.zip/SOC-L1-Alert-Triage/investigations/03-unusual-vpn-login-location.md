# Investigation 03 — Unusual VPN Login Location

**Priority:** 3  
**Alert time:** 21 March 2025, 12:40  
**Severity:** Medium  
**Recorded verdict:** False Positive  
**Recorded status:** Closed  
**Assignee shown:** T.Ross (L1)

## Alert details

| Field | Value |
|---|---|
| Source IP | `45.8.112.7` |
| Source user | `M.Clark` |
| Login country | Japan |
| Expected country | United States |
| User context | Corporate CFO |

## Investigation

The alert was generated because the account authenticated to the corporate VPN from a first-seen country that differed from its expected location.

The alert comment states that M.Clark confirmed she was on vacation in Japan and accessed the VPN from her laptop to resolve an urgent work issue.

## Triage result

- User confirmation provided a plausible business explanation.
- The dashboard records the alert as **Medium**, **Closed**, and **False Positive**.
- The alert remained assigned to T.Ross (L1), as shown in the screenshot.

## Additional validation recommended

User confirmation is useful but should be supported by available authentication telemetry. Check MFA outcome, device identity, VPN session details, impossible-travel context, IP reputation, and whether the access matched the user's normal device and behaviour.

If those checks support the user's explanation and no other indicators are present, a False Positive classification is reasonable. If evidence conflicts with the explanation, escalate for account-compromise investigation.
