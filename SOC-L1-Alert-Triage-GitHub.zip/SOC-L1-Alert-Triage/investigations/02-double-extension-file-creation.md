# Investigation 02 — Double-Extension File Creation

**Priority:** 2  
**Alert time:** 21 March 2025, 13:58  
**Severity:** High  
**Recorded verdict:** True Positive  
**Recorded status:** Closed  
**Assignee shown:** You (L1)

## Alert details

| Field | Value |
|---|---|
| Host | `LPT-HR-009` |
| Process | `chrome.exe` |
| Process user | `S.Conway` |
| Target file | `C:\Users\S.Conway\Downloads\cats2025.mp4.exe` |
| Mark-of-the-Web URL | `https://freecatvideoshd.monster/cats2025.mp4.exe` |
| MD5 | `14d8486f3f63875ef93cfd240c5dc10b` |

## Why it is suspicious

The filename ends in `.exe`, meaning it is an executable despite the misleading `.mp4` portion. Double extensions are a common social-engineering technique used to make executable files look like harmless media.

The file was downloaded by Chrome from a domain that should be treated as untrusted unless independently verified.

## Triage performed

- Reviewed the host, user, process, target path, download URL, and MD5.
- Identified the executable extension hidden behind a media-looking filename.
- The dashboard screenshot records the alert as **High**, **Closed**, and **True Positive**.

## Recommended response

1. Do not open or execute the file.
2. Isolate the endpoint if execution or compromise is suspected, following the organisation's response procedure.
3. Preserve the file and relevant endpoint/browser telemetry for controlled analysis.
4. Search EDR telemetry for process creation, persistence, network connections, and child processes associated with the file.
5. Check whether other endpoints downloaded the same hash or URL.
6. Escalate confirmed malware activity to L2/incident response and follow containment and eradication procedures.

**Safety:** Do not visit the suspicious download URL or execute the file on a normal workstation.
