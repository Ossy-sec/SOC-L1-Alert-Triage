# Investigation 01 — Potential Data Exfiltration

**Priority:** 1  
**Alert time:** 21 March 2025, 13:30  
**Severity:** Critical  
**Recorded dashboard verdict:** True Positive  
**Recorded status:** Closed  
**Assignee shown:** You (L1)

## Alert details

| Field | Value |
|---|---|
| Destination | `*.zoom.us` |
| Source IP | `192.168.45.66` |
| Source network | `UK04/MEETINGROOM` |
| Sent data | 5.8 GB |
| Received data | 5.2 GB |

## Detection logic

The rule identifies 5 GB or more of data sent from one device to one destination within a day. This can indicate possible data exfiltration, but volume alone does not prove malicious activity.

## Triage performed

- Reviewed the destination, source IP, network segment, and transfer volume.
- Assigned the alert to the L1 analyst.
- The dashboard screenshot records the alert as **Critical**, **Closed**, and **True Positive**.

## Evidence assessment and follow-up

The analyst comment saved in the screenshot states that the transfer may be legitimate Zoom conferencing traffic and that there was no clear evidence of malicious exfiltration. That rationale conflicts with the recorded **True Positive** verdict.

Before final closure in a real SOC, investigate:

1. Which endpoint and user generated the traffic?
2. Was there a scheduled or recorded Zoom meeting at that time?
3. Was the traffic sent to an expected Zoom service endpoint?
4. What data was transferred, and was it sensitive or regulated?
5. Do proxy, firewall, DNS, EDR, or cloud logs show unusual processes or staging activity?

## Recommended disposition

Keep the alert escalated or in progress until the transfer is validated. If unauthorised sensitive data transfer is confirmed, retain **True Positive**, preserve evidence, contain the endpoint if warranted, and escalate to L2/incident response. If business-approved conferencing explains the traffic and no suspicious context exists, classify it as **False Positive** or the organisation's appropriate benign classification.

**Portfolio note:** The recorded dashboard verdict is preserved for accuracy, but the evidence/comment mismatch is called out rather than presented as a confirmed malicious exfiltration incident.
