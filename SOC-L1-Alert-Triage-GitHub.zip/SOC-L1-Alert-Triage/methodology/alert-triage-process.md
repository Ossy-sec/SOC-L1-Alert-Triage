# SOC L1 Alert Triage Methodology

This workflow summarises a practical first-line alert handling process.

## 1. Take ownership

- Check whether another analyst already owns or is investigating the alert.
- Assign the alert to yourself when appropriate.
- Move it to **In Progress**.

## 2. Prioritise

A common starting point is:
1. Review only new, unresolved alerts.
2. Sort by severity: Critical, High, Medium, then Low.
3. Within the same severity, consider the oldest alert first.

Follow the organisation's severity matrix and escalation SLAs; severity alone is not a substitute for context.

## 3. Understand the alert

Capture:
- Alert name, timestamp, severity, and detection logic
- Affected user, host, IP address, process, file, or destination
- Relevant event details and any available IOCs

## 4. Investigate

- Establish what happened and who or what was affected.
- Review surrounding events before and after the alert.
- Correlate endpoint, identity, network, DNS, proxy, firewall, and cloud telemetry as relevant.
- Validate indicators using approved threat-intelligence sources.
- Seek user or system-owner confirmation where appropriate.
- Record evidence and note gaps or uncertainty.

## 5. Classify

- **True Positive:** Evidence supports that the detection identified genuinely malicious or policy-violating activity.
- **False Positive:** The detection fired, but investigation shows the activity was benign or expected.
- Use other classifications (such as benign positive) only if the platform and organisation define them.

Do not choose a verdict simply because an alert sounds suspicious or because a user says an action was legitimate. Base it on corroborating evidence.

## 6. Document and resolve

An analyst comment should include:
- What was observed
- What evidence was checked
- What was confirmed or not confirmed
- Why the verdict was selected
- Actions taken and recommended next steps
- Whether escalation is required

Make sure the status, verdict, and written comment agree. Close only when the required L1 checks are complete; otherwise escalate or leave the alert in progress according to procedure.
